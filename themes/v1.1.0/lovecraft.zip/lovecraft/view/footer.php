        <div class="footer section big-padding bg-white">

            <div class="section-inner">

                <div class="widgets">

                    <div class="widget Widget_Lovecraft_Recent_Posts">

                        <div class="widget-content">

                            <h3 class="widget-title">Recent Posts</h3>

                            <ul class="lovecraft-widget-list">

<?php
								$getValues = getOptionalValues(/*TABLE*/"__blog",/*COLUMNS*/"id,blog_seo_title,blog_seo_description,blog_seo_link",/*WHERE*/"blog_do_share_mode=1",/*ORDER BY*/"id",/*ASC DESC*/"DESC",/*LIMIT*/8,NULL);
								if(count($getValues)>1){
									for($i=0; $i<count($getValues); $i++){
										echo '<li>
										<a href="'.$linkify->base_url().'blogs/'.$getValues[$i]['id'].'-'.$getValues[$i]['blog_seo_link'].'">
											<div class="post-icon">
												<div class="genericon genericon-standard"></div>
											</div>
											<div class="inner">
												<p class="title">'.$getValues[$i]['blog_seo_title'].'</p>
												<p class="meta">December 30, 2014</p>
											</div>
											<div class="clear"></div>
										</a>
									</li>';
									}
								}
?>
                                




                            </ul>

                        </div>

                        <div class="clear"></div>
                    </div>
                </div>

                <div class="widgets">

                    <div class="widget Widget_Lovecraft_Recent_Comments">

                        <div class="widget-content">

                            <h3 class="widget-title">Recent Comments</h3>

                            <ul class="lovecraft-widget-list">


                               
<?php
												$getValu = getOptionalValues(/*TABLE*/"__comments",/*COLUMNS*/"id,comment_type,comment_targetid,comment_namesurname,comment_email,comment_website,comment_title,comment_share_strtotime,comment_content",/*WHERE*/"comment_action=1",/*ORDER BY*/"id",/*ASC DESC*/"DESC",/*LIMIT*/4,NULL);
													if(count($getValu)>1){
														for($i=0; $i<count($getValu); $i++){
															if($getValu[$i]['comment_type']=="blog"){
																$articleTitle = selectInTable("__blog","*","id=".$getValu[$i]['comment_targetid'])[0];
																echo '
																<li>
																	<a href="blogs/'.$getValu[$i]['comment_targetid'].'-'.$articleTitle['blog_seo_link'].'">
																		<div class="">
																			<p class="title">
																				<span>'.$getValu[$i]['comment_namesurname'].'</span>
																				<p>'.$articleTitle['blog_seo_title'].'</p>
																			</p>
																			<p class="excerpt">'.$getValu[$i]['comment_title'].'</p>
																			<p class="excerpt">'.mb_substr($getValu[$i]['comment_content'],0,120,'UTF-8').'...</p>
																			
																		</div>
																		<div class="clear"></div>
																	</a>
																</li>';
															}
															
														}
													}
?>

                                
                                



                            </ul>

                        </div>

                        <div class="clear"></div>
                    </div>
                </div>

                <div class="widgets">

                    <div class="widget widget_tag_cloud">

                        <div class="widget-content">

                            <h3 class="widget-title">Tag Cloud</h3>

                            <div class="tagcloud">
							
							<?php $term_count = count(selectInTable("__blog_terms","*","term_type_id=1 ORDER BY term_using_count DESC limit 20"));
											if($term_count>0){
							?>
							<?php
							for($i=0; $i<$term_count; $i++){
													$name = selectInTable("__blog_terms","*","term_type_id=1 ORDER BY term_using_count DESC limit $term_count")[$i]['term_name'];
													$seo = selectInTable("__blog_terms","*","term_type_id=1 ORDER BY term_using_count DESC limit $term_count")[$i]['term_link'];
													echo '<a style="font-size: 8pt;" class="tag-cloud-link tag-link-13 tag-link-position-1" href="'.$linkify->base_url().'search/'.$seo.'">'.$name.'</a>';
							}
							}
							?>
                            </div>
                        </div>

                        <div class="clear"></div>
                    </div>
                </div>

                <div class="clear"></div>

            </div><!-- .section-inner -->

        </div><!-- .footer.section -->


        <div class="credits section bg-dark">

            <div class="credits-inner section-inner">

                <p>Powered by Linker CMS <span class="sep">&amp;</span>

                    <span>Theme by

                        <a href="https://www.andersnoren.se">Anders Nor&eacute;n</a>
                    </span>
                </p>

            </div><!-- .section-inner -->

        </div><!-- .credits.section -->


        <script
            src='<?php echo $linkify->base_url(); ?>content/themes/lovecraft/assets/js/comment-reply.min.js?ver=5.2.1'
            type='text/javascript'></script>



    </body>
</html>