<div class="sidebar">

                    <div class="widget widget_search">

                        <div class="widget-content">

                            <form
                                action="<?php echo $linkify->base_url(); ?>search"
                                class="search-form"
                                id="search-form"
                                method="get">

                                <input
                                    name="s"
                                    class="search-field"
                                    id="s"
                                    placeholder="Search form"
                                    type="search" />

                                <button
                                    class="search-button"
                                    type="submit">

                                    <div class="genericon genericon-search"></div>

                                    <span class="screen-reader-text">Search</span>
                                </button>
                            </form>
                        </div>

                        <div class="clear"></div>
                    </div>

                    <div class="widget widget_text">

                        <div class="widget-content">

                            <h3 class="widget-title">About Lovecraft</h3>

                            <div class="textwidget">

                                <p>Lovecraft is a beautiful WordPress theme for bloggers. It is
                                    available as a free download from the
                                    official <a href="http://www.wordpress.org/themes/lovecraft/">
                                        WordPress theme depository</a>.
                                </p>

                                <p>Lovecraft is developed by <a href="http://www.andersnoren.se/">
                                    Anders Norn</a>.
                                </p>
                            </div>
                        </div>

                        <div class="clear"></div>
                    </div>

                    <div class="widget widget_categories">

                        <div class="widget-content">

                            <h3 class="widget-title">Categories</h3>

                            <ul>

                                							
							<?php
									$parents = getOptionalValues(/*TABLE*/"__blog_categories",/*COLUMNS*/"id,parent,parent_id,ranking_id,category_name,category_link",/*WHERE*/"parent=1 and visibility=1",/*ORDER BY*/"ranking_id",/*ASC DESC*/"ASC",/*LIMIT*/25,NULL);
									$category = getOptionalValues(/*TABLE*/"__blog_categories",/*COLUMNS*/"id,parent,parent_id,ranking_id,category_name,category_link",/*WHERE*/"parent=0 and visibility=1",/*ORDER BY*/"ranking_id",/*ASC DESC*/"ASC",/*LIMIT*/25,NULL);
									if(count($parents)>=1){
										for($i=0; $i<count($parents); $i++){
											echo '<li>';
												if(count($category)>=1){
													echo '<a href="#"><div><b>'.$parents[$i]['category_name'].'</b></div></a>
															<ul>';
													for($j=0; $j<count($category); $j++){
														if($category[$j]['parent_id']==$parents[$i]['id']){
															echo '<li><a href="'.$linkify->base_url().'category/'.$category[$j]['category_link'].'"><div>'.$category[$j]['category_name']."</div></a></li>";
														}
													}
													echo '</ul>';
												}
											echo "</li>";
										}
									}
							?>
							
                            </ul>
                        </div>

                        <div class="clear"></div>
                    </div>
                </div><!-- .sidebar -->