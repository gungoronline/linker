        <div class="wrapper section">

            <div class="section-inner">

                <div class="content">
					
					<div
                        class="post single post-82 page type-page status-publish hentry"
                        id="post-82">
                        <div class="post-inner">
                            <div class="post-header">
                                <h1 class="post-title">Contact</h1>
                            </div><!-- .post-header -->
                            <div class="post-content">
                                <p>If you contact with me. Fill the form.</p>
                            </div>
                            <div class="clear"></div>
                        </div><!-- .post-inner -->
                        <div class="respond-container">

                            <div
                                class="comment-respond"
                                id="respond">

                                <h3
                                    class="comment-reply-title"
                                    id="reply-title">Leave a Message

                                    <small>

                                        <a
                                            style="display:none;"
                                            href="/themes/lovecraft/page-templates/full-width-template/#respond"
                                            id="cancel-comment-reply-link"
                                            rel="nofollow">Cancel Message
                                        </a>
                                    </small>
                                </h3>

                                <form
                                    action="https://andersnoren.se/themes/lovecraft/wp-comments-post.php"
                                    class="comment-form"
                                    id="commentform"
                                    method="post">

                                    <p class="comment-notes">

                                        <span id="email-notes">Your email address will not be
                                            published.
                                        </span>
                                        Required fields are marked

                                        <span class="required">*</span>
                                    </p>

                                    <p class="comment-form-comment">

                                        <label for="comment">Comment</label>

                                        <textarea
                                            name="comment"
                                            cols="45"
                                            id="comment"
                                            maxlength="65525"
                                            required="required"
                                            rows="8"></textarea>
                                    </p>

                                    <p class="comment-form-author">

                                        <label for="author">Name

                                            <span class="required">*</span>
                                        </label>

                                        <input
                                            name="author"
                                            id="author"
                                            maxlength="245"
                                            required='required'
                                            size="30"
                                            type="text"
                                            value="" />
                                    </p>

                                    <p class="comment-form-email">

                                        <label for="email">Email

                                            <span class="required">*</span>
                                        </label>

                                        <input
                                            name="email"
                                            aria-describedby="email-notes"
                                            id="email"
                                            maxlength="100"
                                            required='required'
                                            size="30"
                                            type="text"
                                            value="" />
                                    </p>

                                    <p class="comment-form-url">

                                        <label for="url">Website</label>

                                        <input
                                            name="url"
                                            id="url"
                                            maxlength="200"
                                            size="30"
                                            type="text"
                                            value="" />
                                    </p>

                                    <p class="form-submit">

                                        <input
                                            name="submit"
                                            class="submit"
                                            id="submit"
                                            type="submit"
                                            value="Sent Message" />

                                        <input
                                            name='comment_post_ID'
                                            id='comment_post_ID'
                                            type='hidden'
                                            value='82' />

                                        <input
                                            name='comment_parent'
                                            id='comment_parent'
                                            type='hidden'
                                            value='0' />
                                    </p>

                                    <p style="display: none;">

                                        <input
                                            name="akismet_comment_nonce"
                                            id="akismet_comment_nonce"
                                            type="hidden"
                                            value="8e5b0ab15b" />
                                    </p>

                                    <p style="display: none;">

                                        <input
                                            name="ak_js"
                                            id="ak_js"
                                            type="hidden"
                                            value="102" />
                                    </p>
                                </form>
                            </div><!-- #respond -->
                        </div><!-- .respond-container -->
                    </div><!-- .post -->


                </div><!-- .content -->

                <?php require_once('content/themes/lovecraft/controller/sidebar.php'); ?>

                <div class="clear"></div>


            </div><!-- .section-inner -->

        </div><!-- .wrapper -->