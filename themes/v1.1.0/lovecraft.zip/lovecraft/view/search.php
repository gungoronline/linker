<div class="wrapper section">

	<div class="section-inner">

		<div class="content">

			
				<div class="page-title">

					<h4>

						Tag: <?php echo @$_GET['s']; ?>
						
					</h4>

				</div><!-- .page-title -->

			
			
				<div class="posts" id="posts">

					<div id="post-28" class="post post-28 type-post status-publish format-standard has-post-thumbnail hentry category-apple category-tech tag-apple-2 tag-mac tag-macbook-air">

	
	
		<a class="post-image" href="https://andersnoren.se/themes/lovecraft/macbook-air-13-2013/">
			<img width="900" height="506" src="https://andersnoren.se/themes/lovecraft/wp-content/uploads/2014/01/macbook-air-900x506.jpg" class="attachment-post-image size-post-image wp-post-image" alt="" srcset="https://andersnoren.se/themes/lovecraft/wp-content/uploads/2014/01/macbook-air-900x506.jpg 900w, https://andersnoren.se/themes/lovecraft/wp-content/uploads/2014/01/macbook-air-300x169.jpg 300w, https://andersnoren.se/themes/lovecraft/wp-content/uploads/2014/01/macbook-air-1024x576.jpg 1024w, https://andersnoren.se/themes/lovecraft/wp-content/uploads/2014/01/macbook-air.jpg 1280w" sizes="(max-width: 900px) 100vw, 900px" />		</a><!-- .featured-media -->

	
	<div class="post-inner">

		
			<div class="post-header">

				
					<h2 class="post-title"><a href="https://andersnoren.se/themes/lovecraft/macbook-air-13-2013/">MacBook Air 13&#8243; 2013</a></h2>

							
		<div class="post-meta">

			<p class="post-author"><span>By </span><a href="https://andersnoren.se/themes/lovecraft/author/anders/" title="Posts by Anders Norén" rel="author">Anders Norén</a></p>

			<p class="post-date"><span>On </span><a href="https://andersnoren.se/themes/lovecraft/macbook-air-13-2013/">January 31, 2014</a></p>

							<p class="post-categories"><span>In </span><a href="https://andersnoren.se/themes/lovecraft/category/tech/apple/" rel="category tag">Apple</a>, <a href="https://andersnoren.se/themes/lovecraft/category/tech/" rel="category tag">Tech</a></p>
			
			
		</div>

		
			</div><!-- .post-header -->

		
		
			<div class="post-content">
				<p class="intro">The Air was designed to balance both performance and portability; it has a full-sized keyboard design and a machined aluminium casing with extremely low weight and thickness.</p>
<p>The MacBook Air is designed for thinness; it is also lighter than most competing models. The computer features a glossy LED backlit display and a full-size keyboard, as well as a large trackpad that responds to Multi-Touch gestures such as pinching, swiping, and rotating. With the release of Mac OS X Snow Leopard, the Air&#8217;s multi-touch trackpad also supports handwriting recognition of Chinese characters.</p>
<p><a class="more-link" href="https://andersnoren.se/themes/lovecraft/macbook-air-13-2013/">Read More</a></p>
			</div>

			<div class="clear"></div>

			
	</div><!-- .post-inner -->

</div><!-- .post -->

				</div><!-- .posts -->

				
			
		</div><!-- .content -->
		
		  <?php require_once('content/themes/lovecraft/controller/sidebar.php'); ?>

		<div class="clear"></div>

	</div><!-- .section-inner -->

</div><!-- .wrapper -->		
		