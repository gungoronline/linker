        <div class="wrapper section">

            <div class="section-inner">

                <div class="content">


                    <div
                        class="post single post-7 page type-page status-publish hentry"
                        id="post-7">

                        <div class="post-inner">

                            <div class="post-header">

                                <h1 class="post-title">

                                    <a href="https://andersnoren.se/themes/lovecraft/about-lovecraft/">
                                        About Lovecraft
                                    </a>
                                </h1>


                            </div><!-- .post-header -->


                            <div class="post-content">

                                <p>Lovecraft is a clean, beautiful and responsive two-column theme
                                    for bloggers. It has been submitted to the <a href="http://www.wordpress.org/themes/hemingway/">
                                        WordPress Theme Depository
                                    </a> where it soon will be available as a free download.
                                </p>

                                <p>Lovecraft is developed by <a href="http://www.andersnoren.se">
                                    Anders Norén</a>. While you&#8217;re at it, feel free to check
                                    out some of my <a href="http://www.andersnoren.se/teman/">other
                                        themes</a>.
                                </p>

                                <h3>Features in Lovecraft</h3>

                                <p>

                                    <strong>Beautiful Design</strong>

                                    <br />
                                    Lovecraft features a crisp, beautiful two-column design that
                                    does your content justice. A big header image makes a striking
                                    first impression, and it&#8217;s replaced with the post
                                    thumbnail on single posts and pages.
                                </p>

                                <p>

                                    <strong>Responsive and Retina Ready</strong>

                                    <br />
                                    The beautiful design is built to scale gracefully to any and all
                                    screen sizes – from a 27&#8243; desktop display to a 3.5&#8243;
                                    smartphone. The navigation and search form is hidden behind
                                    easy-to-access toggles on mobile.
                                </p>

                                <p>

                                    <strong>Great Typography</strong>

                                    <br />
                                    From the blog title to the image captions, every part of the
                                    typography in Lovecraft is thoroughly considered. The body text
                                    is set in a sharp serif font that will make your content a joy
                                    to read.
                                </p>

                                <p>

                                    <strong>Customizability</strong>

                                    <br />
                                    Switch the default header image to one of your own, change the
                                    accent color in the built-in theme customizer, upload your own
                                    logo and use the four widget areas to give Lovecraft a personal
                                    touch.
                                </p>

                                <p>

                                    <strong>Jetpack Support</strong>

                                    <br />
                                    Lovecraft has built-in support for Jetpacks Infinite Scroll
                                    function, which means that new posts will be loaded as soon as
                                    you reach the bottom of the page. You can also use the Jetpack
                                    Tiled Galleries function to display posts in a beautiful masonry
                                    grid.
                                </p>

                                <p>

                                    <strong>Plus</strong>

                                    <br />
                                    Lovecraft also features editor styles, a full-width page
                                    template, three custom widgets and translation ready code
                                    (included translations: Swedish/svenska).
                                </p>

                            </div>

                            <div class="clear"></div>


                        </div><!-- .post-inner -->


                        <div class="comments-container">

                            <div class="comments-inner">

                                <a name="comments"></a>

                                <div class="comments-title-container">

                                    <h2 class="comments-title">

                                        1 Comment</h2>


                                    <p class="comments-title-link">

                                        <a href="#respond">Add Comment &rarr;</a>

                                    </p>


                                    <div class="clear"></div>

                                </div>

                                <div class="comments">

                                    <ol class="commentlist">

                                        <li
                                            class="comment even thread-even depth-1"
                                            id="li-comment-2">

                                            <div
                                                class="comment"
                                                id="comment-2">

                                                <img
                                                    alt=''
                                                    class='avatar avatar-160 photo'
                                                    height='160'
                                                    src='https://secure.gravatar.com/avatar/b642b4217b34b1e8d3bd915fc65c4452?s=160&#038;d=mm&#038;r=g'
                                                    srcset='https://secure.gravatar.com/avatar/b642b4217b34b1e8d3bd915fc65c4452?s=320&#038;d=mm&#038;r=g 2x'
                                                    width='160' />

                                                <div class="comment-inner">

                                                    <div class="comment-header">

                                                        <h4>the w</h4>

                                                    </div><!-- .comment-header -->

                                                    <div class="comment-content post-content">

                                                        <p>greate theme!</p>

                                                    </div><!-- .comment-content -->

                                                    <div class="comment-meta">

                                                        <div class="fleft">

                                                            <div class="genericon genericon-day"></div>

                                                            <a
                                                                class="comment-date-link"
                                                                href="https://andersnoren.se/themes/lovecraft/about-lovecraft/#comment-2"
                                                                title="April 1, 2014 at 19:14">April
                                                                1, 2014
                                                            </a>
                                                        </div>

                                                        <div class="fright">

                                                            <div class="genericon genericon-reply"></div>

                                                            <a
                                                                aria-label='Reply to the w'
                                                                class='comment-reply-link'
                                                                data-belowelement="comment-2"
                                                                data-commentid="2"
                                                                data-postid="7"
                                                                data-respondelement="respond"
                                                                href='/themes/lovecraft/about-lovecraft/?replytocom=2#respond'
                                                                rel='nofollow'>Reply
                                                            </a>
                                                        </div>

                                                        <div class="clear"></div>

                                                    </div><!-- .comment-meta -->

                                                </div><!-- .comment-inner -->

                                            </div><!-- .comment-## -->

                                        </li><!-- #comment-## -->
                                    </ol>


                                </div><!-- .comments -->

                            </div><!-- .comments-inner -->

                        </div><!-- .comments-container -->

                        <div class="respond-container">

                            <div
                                class="comment-respond"
                                id="respond">

                                <h3
                                    class="comment-reply-title"
                                    id="reply-title">Leave a Reply

                                    <small>

                                        <a
                                            style="display:none;"
                                            href="/themes/lovecraft/about-lovecraft/#respond"
                                            id="cancel-comment-reply-link"
                                            rel="nofollow">Cancel reply
                                        </a>
                                    </small>
                                </h3>

                                <form
                                    action="https://andersnoren.se/themes/lovecraft/wp-comments-post.php"
                                    class="comment-form"
                                    id="commentform"
                                    method="post">

                                    <p class="comment-notes">

                                        <span id="email-notes">Your email address will not be
                                            published.
                                        </span>
                                        Required fields are marked

                                        <span class="required">*</span>
                                    </p>

                                    <p class="comment-form-comment">

                                        <label for="comment">Comment</label>

                                        <textarea
                                            name="comment"
                                            cols="45"
                                            id="comment"
                                            maxlength="65525"
                                            required="required"
                                            rows="8"></textarea>
                                    </p>

                                    <p class="comment-form-author">

                                        <label for="author">Name

                                            <span class="required">*</span>
                                        </label>

                                        <input
                                            name="author"
                                            id="author"
                                            maxlength="245"
                                            required='required'
                                            size="30"
                                            type="text"
                                            value="" />
                                    </p>

                                    <p class="comment-form-email">

                                        <label for="email">Email

                                            <span class="required">*</span>
                                        </label>

                                        <input
                                            name="email"
                                            aria-describedby="email-notes"
                                            id="email"
                                            maxlength="100"
                                            required='required'
                                            size="30"
                                            type="text"
                                            value="" />
                                    </p>

                                    <p class="comment-form-url">

                                        <label for="url">Website</label>

                                        <input
                                            name="url"
                                            id="url"
                                            maxlength="200"
                                            size="30"
                                            type="text"
                                            value="" />
                                    </p>

                                    <p class="form-submit">

                                        <input
                                            name="submit"
                                            class="submit"
                                            id="submit"
                                            type="submit"
                                            value="Post Comment" />

                                        <input
                                            name='comment_post_ID'
                                            id='comment_post_ID'
                                            type='hidden'
                                            value='7' />

                                        <input
                                            name='comment_parent'
                                            id='comment_parent'
                                            type='hidden'
                                            value='0' />
                                    </p>

                                    <p style="display: none;">

                                        <input
                                            name="akismet_comment_nonce"
                                            id="akismet_comment_nonce"
                                            type="hidden"
                                            value="1ab7d66a32" />
                                    </p>

                                    <p style="display: none;">

                                        <input
                                            name="ak_js"
                                            id="ak_js"
                                            type="hidden"
                                            value="119" />
                                    </p>
                                </form>
                            </div><!-- #respond -->
                        </div><!-- .respond-container -->
                    </div><!-- .post -->


                </div><!-- .content -->

                <?php require_once('content/themes/lovecraft/controller/sidebar.php'); ?>

                <div class="clear"></div>


            </div><!-- .section-inner -->

        </div><!-- .wrapper -->