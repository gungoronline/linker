        <div class="wrapper section">

            <div class="section-inner">

                <div class="content">


                    <div
                        class="posts"
                        id="posts">

                        
<?php 
				
$getNewBlogs = getOptionalValues("__blog","id,blog_seo_title,blog_seo_description,blog_seo_link,blog_seo_ogimage","blog_do_share_mode=1","id","DESC",5,NULL);
if(count($getNewBlogs)>0){
	for($i=0; $i<count($getNewBlogs); $i++){
				
?>
                        <div
                            class="post post-28 type-post status-publish format-standard has-post-thumbnail hentry category-apple category-tech tag-apple-2 tag-mac tag-macbook-air"
                            id="post-28">
                            <a
                                class="post-image"
                                href="<?php echo $linkify->base_url()."blogdetail/".$getNewBlogs[$i]['id']."-".$getNewBlogs[$i]['blog_seo_link']; ?>">
                                <img
                                    alt=""
                                    class="attachment-post-image size-post-image wp-post-image"
                                    height="506"
                                    sizes="(max-width: 900px) 100vw, 900px"
                                    src="<?php echo $linkify->base_url().$getNewBlogs[$i]['blog_seo_ogimage']; ?>"
                                    width="900" />
                            </a><!-- .featured-media -->
                            <div class="post-inner">
                                <div class="post-header">
                                    <h2 class="post-title">
                                        <a href="<?php echo $linkify->base_url()."blogdetail/".$getNewBlogs[$i]['id']."-".$getNewBlogs[$i]['blog_seo_link']; ?>"><?php echo $getNewBlogs[$i]['blog_seo_title']; ?></a>
                                    </h2>
                                    <div class="post-meta">
                                        <p class="post-author">
                                            <span>By</span>
                                            <a
                                                href="author/anders/index.html"
                                                rel="author"
                                                title="Posts by Anders Norén">Anders Norén
                                            </a>
                                        </p>
                                        <p class="post-date">
                                            <span>On</span>
                                            <a href="<?php echo $linkify->base_url()."blogdetail/".$getNewBlogs[$i]['id']."-".$getNewBlogs[$i]['blog_seo_link']; ?>"><?php echo date('d.m.Y',intval($getNewBlogs[$i]['blog_share_strtotime'])); ?></a>
                                        </p>
                                        <p class="post-categories">
                                            <span>In</span>
                                            <a
                                                href="category/tech/apple/index.html"
                                                rel="category tag">Apple</a>,
                                            <a
                                                href="category/tech/index.html"
                                                rel="category tag">Tech
                                            </a>
                                        </p>
                                    </div>
                                </div><!-- .post-header -->
                                <div class="post-content">
                                    <p class="intro"><?php echo $getNewBlogs[$i]['blog_seo_description']; ?></p>
                                        <a class="more-link" href="<?php echo $linkify->base_url()."blogdetail/".$getNewBlogs[$i]['id']."-".$getNewBlogs[$i]['blog_seo_link']; ?>">Read More</a>
                                    </p>
                                </div>
                                <div class="clear"></div>
                            </div><!-- .post-inner -->
                        </div><!-- .post -->
<?php  
}
	}
?>
						
                        

                    </div><!-- .posts -->


                    <div class="archive-navigation">

                        <div class="fleft">

                            <p>Page 1 of 2</p>

                        </div>

                        <div class="fright">


                            <p>

                                <a href="page/2/index.html">Next &rarr;</a>
                            </p>


                        </div>

                        <div class="clear"></div>

                    </div><!-- .archive-nav -->


                </div><!-- .content -->

                <?php require_once('content/themes/lovecraft/controller/sidebar.php'); ?>

                <div class="clear"></div>

            </div><!-- .section-inner -->

        </div><!-- .wrapper -->