        <div class="wrapper section">

            <div class="section-inner">

                <div class="content">


                    <div class="page-title">

                        <h4>

                            Category: Personal

                        </h4>

                    </div><!-- .page-title -->


                    <div
                        class="posts"
                        id="posts">

                        <div
                            class="post post-20 type-post status-publish format-standard has-post-thumbnail hentry category-lifestyle category-personal category-work tag-beverages tag-coffee tag-developers"
                            id="post-20">


                            <a
                                class="post-image"
                                href="drink-more-coffee-developers/">

                                <img
                                    alt=""
                                    class="attachment-post-image size-post-image wp-post-image"
                                    height="506"
                                    sizes="(max-width: 900px) 100vw, 900px"
                                    src="uploads/2014/01/coffee-900x506.jpg"
                                    srcset="uploads/2014/01/coffee-900x506.jpg 900w, uploads/2014/01/coffee-300x169.jpg 300w, uploads/2014/01/coffee-1024x576.jpg 1024w, uploads/2014/01/coffee.jpg 1280w"
                                    width="900" />
                            </a><!-- .featured-media -->


                            <div class="post-inner">


                                <div class="post-header">


                                    <h2 class="post-title">

                                        <a href="drink-more-coffee-developers/">
                                            Drink More Coffee, Developers
                                        </a>
                                    </h2>


                                    <div class="post-meta">

                                        <p class="post-author">

                                            <span>By</span>

                                            <a
                                                href="author/anders/"
                                                rel="author"
                                                title="Posts by Anders Norén">Anders Norén
                                            </a>
                                        </p>

                                        <p class="post-date">

                                            <span>On</span>

                                            <a href="drink-more-coffee-developers/">
                                                January 31, 2014
                                            </a>
                                        </p>

                                        <p class="post-categories">

                                            <span>In</span>

                                            <a
                                                href="category/lifestyle/"
                                                rel="category tag">Lifestyle</a>, <a
                                            href="category/personal/"
                                            rel="category tag">Personal</a>,

                                            <a
                                                href="category/work/"
                                                rel="category tag">Work
                                            </a>
                                        </p>


                                    </div>


                                </div><!-- .post-header -->


                                <div class="post-content">

                                    <p>Coffee is a brewed beverage with a distinct aroma and flavor,
                                        prepared from the roasted seeds of the Coffea plant. The
                                        seeds are found in coffee cherries, which grow on trees
                                        cultivated in over 70 countries.</p>

                                    <p>Roasting coffee transforms the chemical and physical
                                        properties of green coffee beans into roasted coffee
                                        products. The roasting process is what produces the
                                        characteristic flavor of coffee by causing the green coffee
                                        beans to expand and to change in color, taste, smell, and
                                        density. Unroasted beans contain similar acids, protein, and
                                        caffeine as those that have been roasted, but lack the
                                        taste. Heat must be applied for the Maillard and other
                                        chemical reactions to occur.</p>

                                    <p>

                                        <a
                                            class="more-link"
                                            href="drink-more-coffee-developers/">
                                            Read More
                                        </a>
                                    </p>
                                </div>

                                <div class="clear"></div>


                            </div><!-- .post-inner -->

                        </div><!-- .post -->

                    </div><!-- .posts -->


                </div><!-- .content -->

                <?php require_once('content/themes/lovecraft/controller/sidebar.php'); ?>

                <div class="clear"></div>

            </div><!-- .section-inner -->

        </div><!-- .wrapper -->