﻿<!DOCTYPE html>

<html
    class="no-js"
    lang="en-US">

    <head profile="http://gmpg.org/xfn/11">

        <meta
            content="text/html; charset=UTF-8"
            http-equiv="Content-Type" />

        <meta
            name="viewport"
            content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

        <title>About Lovecraft &#8211; Lovecraft</title>

        <script>document.documentElement.className =
            document.documentElement.className.replace("no-js","js");</script>

        <link
            href='<?php echo $linkify->base_url(); ?>content/themes/lovecraft/assets/css/dist/block-library/style.min7752.css?ver=5.2.1'
            id='wp-block-library-css'
            media='all'
            rel='stylesheet'
            type='text/css' />

        <link
            href='http://fonts.googleapis.com/css?family=Lato%3A400%2C700%2C900%7CPlayfair+Display%3A400%2C700%2C400italic&amp;ver=5.2.1'
            id='lovecraft_googlefonts-css'
            media='all'
            rel='stylesheet'
            type='text/css' />

        <link
            href='<?php echo $linkify->base_url(); ?>content/themes/lovecraft/assets/genericons/genericons7752.css?ver=5.2.1'
            id='lovecraft_genericons-css'
            media='all'
            rel='stylesheet'
            type='text/css' />

        <link
            href='<?php echo $linkify->base_url(); ?>content/themes/lovecraft/assets/style7752.css?ver=5.2.1'
            id='lovecraft_style-css'
            media='all'
            rel='stylesheet'
            type='text/css' />

        <script
            src='<?php echo $linkify->base_url(); ?>content/themes/lovecraft/assets/js/jquery/jquery4a5f.js?ver=1.12.4-wp'
            type='text/javascript'></script>

        <script
            src='<?php echo $linkify->base_url(); ?>content/themes/lovecraft/assets/js/jquery/jquery-migrate.min330a.js?ver=1.4.1'
            type='text/javascript'></script>

    </head>

    <body class="page-template-default page page-id-7">


        <div class="header-wrapper">

            <div class="header section bg-white small-padding">

                <div class="section-inner">


                    <h2 class="blog-title">
                        <a
                            href="<?php echo $linkify->base_url(); ?>"
                            rel="home"
                            title="Lovecraft &mdash; A Beautiful Linker CMS Theme For Bloggers">
                            Lovecraft
                        </a>
                    </h2>


                    <h4 class="blog-tagline">
                        A Beautiful Linker CMS Theme For Bloggers</h4>


                    <div class="clear"></div>

                </div><!-- .section-inner -->

            </div><!-- .header -->

            <div class="toggles">

                <button
                    class="nav-toggle toggle"
                    type="button">

                    <div class="bar"></div>

                    <div class="bar"></div>

                    <div class="bar"></div>

                    <span class="screen-reader-text">Toggle the mobile menu</span>
                </button>

                <button
                    class="search-toggle toggle"
                    type="button">

                    <div class="genericon genericon-search"></div>

                    <span class="screen-reader-text">Toggle the search field</span>
                </button>

                <div class="clear"></div>

            </div><!-- .toggles -->

        </div><!-- .header-wrapper -->
		        <div class="navigation bg-white no-padding">

            <div class="section-inner">
                <ul class="mobile-menu">
                    <li
                        class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item menu-item-11"
                        id="menu-item-11">
                        <a aria-current="page" href="<?php echo $linkify->base_url(); ?>index.html">Home</a>
                    </li>
                    <li
                        class="menu-item menu-item-type-post_type menu-item-object-page menu-item-95"
                        id="menu-item-95">

                        <a href="<?php echo $linkify->base_url(); ?>contact">Contact</a>
                    </li>

                </ul>

                <div class="mobile-search">

                    <form
                        action="<?php echo $linkify->base_url(); ?>search"
                        class="search-form"
                        id="search-form"
                        method="get">

                        <input
                            name="s"
                            class="search-field"
                            id="s"
                            placeholder="Search form"
                            type="search" />

                        <button
                            class="search-button"
                            type="submit">

                            <div class="genericon genericon-search"></div>

                            <span class="screen-reader-text">Search</span>
                        </button>
                    </form>

                </div>

                <ul class="main-menu">

                    <li class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item menu-item-11">

                        <a aria-current="page" href="<?php echo $linkify->base_url(); ?>index.html">Home</a>
                    </li>

                    <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-12">

                        <a href="<?php echo $linkify->base_url(); ?>about">About</a>
                    </li>

                    <li class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item menu-item-13">
                        <a href="<?php echo $linkify->base_url(); ?>blogs">Blogs</a>
                    </li>

                    <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-120">

                        <a href="#">Categories</a>

                        <ul class="sub-menu">

                            <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-121">

                                <a href="http://#">Menu Item</a>
                            </li>

                            <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-122">

                                <a href="http://#">Dropdown</a>

                                <ul class="sub-menu">

                                    <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-123">

                                        <a href="http://#">Menu Item</a>
                                    </li>

                                    <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-124">

                                        <a href="http://#">Menu Item</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </li>

                    <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-95">
                        <a href="<?php echo $linkify->base_url(); ?>contact">Contact</a>
                    </li>

                </ul>

                <div class="clear"></div>

            </div><!-- .section-inner -->

        </div><!-- .navigation -->


        <div
            style="background-image: url('<?php echo $linkify->base_url(); ?>content/themes/lovecraft/assets/images/header.jpg');"
            class="header-image bg-image">

            <img
                alt="Lovecraft"
                src="<?php echo $linkify->base_url(); ?>content/themes/lovecraft/assets/images/header.jpg" />

        </div>