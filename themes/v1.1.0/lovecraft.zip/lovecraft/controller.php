<?php
$_url_array = explode("/",$_url);
$ir =  "content/themes/lovecraft/";

require_once($ir."controller/header.php");

if($_url_array[0]=="" or $_url_array[0]=="index.html"){
	require_once($ir."controller/main.php");
}else if($_url_array[0]=="blogs"){
	require_once($ir."controller/blogs.php");
}else if($_url_array[0]=="blogdetails"){
	require_once($ir."controller/blogdetails.php");
}else if($_url_array[0]=="page404"){
	require_once($ir."controller/page404.php");
}else if($_url_array[0]=="search"){
	require_once($ir."controller/search.php");
}else if($_url_array[0]=="about"){
	require_once($ir."controller/about.php");
}else{
	$filename = $_url_array[0];
	$filename = $ir."controller/".$filename.".php";
	if(file_exists($filename)){
		require_once($filename);
	}else{
		require_once($ir."controller/page404.php");
	}
}

require_once($ir."controller/footer.php");


?>