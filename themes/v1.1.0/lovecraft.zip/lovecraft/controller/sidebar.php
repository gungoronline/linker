<?php

require_once("content/themes/lovecraft/view/sidebar.php");