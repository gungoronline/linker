<?php

require_once("content/themes/lovecraft/view/blogdetails.php");