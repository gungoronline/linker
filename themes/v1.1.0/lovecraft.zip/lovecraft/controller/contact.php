<?php

require_once("content/themes/lovecraft/view/contact.php");