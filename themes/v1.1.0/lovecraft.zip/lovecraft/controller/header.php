<?php

require_once("content/themes/lovecraft/view/header.php");