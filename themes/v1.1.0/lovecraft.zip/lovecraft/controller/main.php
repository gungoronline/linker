<?php

require_once("content/themes/lovecraft/view/main.php");