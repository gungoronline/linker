<?php

require_once("content/themes/lovecraft/view/page404.php");